// models/userModel.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({

    firstName: { type: String, required: true },
    lastName: { type: String, required: false },
    email: { type: String, required: true },
    phoneNumber: { type: String, required: true },

    personalInfo: {
        dob: { type: Date },
        gender: { type: String, enum: ['male', 'female', 'other'] },
        address: { type: String },
        bio: { type: String }
    },
    experience: [
        {
            company: { type: String },
            role: { type: String },
            duration: { type: String },
            description: { type: String }
        }
    ],
    socialLinks: {
        linkedIn: { type: String },
        github: { type: String },
        twitter: { type: String },
        website: { type: String }
    },
    referralCode: { type: String },
    referredBy: { type: String }, // If referred by someone else, store their referral code
    graphyUserId: { type: String, default: null }, // Graphy API user ID
    isCompleted: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    role: { type: String, default: 'user', enum: ['user', 'admin'] }

}, { timestamps: true });

module.exports = mongoose.model('users', userSchema);